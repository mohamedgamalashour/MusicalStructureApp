package com.aungmyokyaw.www.musicalstructureapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Home.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Home extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View home = inflater.inflate(R.layout.fragment_home, container, false);

        ArrayList<song> songs = getSong();

        songAdapter songAdapter = new songAdapter(getActivity(),songs);

        //set adapter
        ListView listView = (ListView) home.findViewById(R.id.song);
        listView.setAdapter(songAdapter);

        return home;
    }

    private ArrayList<song> getSong(){
        final ArrayList<song> songs = new ArrayList<song>();

        songs.add(new song("one","1","1","Rock",0,R.drawable.album_art));
        songs.add(new song("two","2","2","Rock",0,R.drawable.album_art));
        songs.add(new song("three","3","3","Rock",0,R.drawable.album_art));
        songs.add(new song("four","4","4","Rock",0,R.drawable.album_art));
        songs.add(new song("five","5","5","Rock",0,R.drawable.album_art));
        songs.add(new song("six","6","6","Rock",0,R.drawable.album_art));
        songs.add(new song("seven","7","7","Rock",0,R.drawable.album_art));
        songs.add(new song("eight","8","8","Rock",0,R.drawable.album_art));
        songs.add(new song("nine","9","9","Rock",0,R.drawable.album_art));
        songs.add(new song("ten","10","10","Rock",0,R.drawable.album_art));


        return songs;
    }
}
