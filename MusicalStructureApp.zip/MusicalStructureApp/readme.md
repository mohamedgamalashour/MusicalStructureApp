# Musical Structure App
> Musical Structure App

![Musical Structure App][image]

[image]: ./media/MusicalStructureApp.png